#!/bin/bash

echo "ADD ./hello.sh in docker success"